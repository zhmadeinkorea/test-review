package org.zerock.domain;

import java.util.Date;
import lombok.Data;

@Data
public class ReplyDTO {
	
	private int rno;
	private String reply;
	private Date replyDate;
	

}
